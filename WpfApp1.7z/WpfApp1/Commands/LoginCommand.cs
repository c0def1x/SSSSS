﻿using Firebase.Auth;
using Firebase.Database;
using Firebase.Database.Query;
using MVVMEssentials.Commands;
using MVVMEssentials.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Navigation;
using WpfApp1.Models;
using WpfApp1.ViewModels;

namespace WpfApp1.Commands
{
    public class LoginCommand : AsyncCommandBase
    {

        private readonly LoginViewModel _loginViewModel;
        private readonly FirebaseAuthProvider _firebaseAuthProvider;
        private readonly INavigationService _taskManagerNavigationService;

        
        public LoginCommand(LoginViewModel loginViewModel,FirebaseAuthProvider firebaseAuthProvider, INavigationService taskManagerNavigationService)
        {
            _loginViewModel = loginViewModel;
            _firebaseAuthProvider = firebaseAuthProvider;
            _taskManagerNavigationService = taskManagerNavigationService;
       
           
        }
        protected override async System.Threading.Tasks.Task ExecuteAsync (object parameter)
        {

            try
            {
                string a = _firebaseAuthProvider.SignInWithEmailAndPasswordAsync(_loginViewModel.Email, _loginViewModel.Password).Result.User.LocalId;
                var firebase = new FirebaseClient("https://user-tasks-b8522-default-rtdb.firebaseio.com/");
                var user = await firebase.Child("users").Child(a).OnceSingleAsync<Models.User>();
                

                if (!user.IsAdmin)
                {
                    MessageBox.Show("Доступ закрыт");
                    return;
                }
                else
                {

                    _taskManagerNavigationService.Navigate();
                    Application.Current.MainWindow.Height = 1024;
                    Application.Current.MainWindow.Width = 1440; 
                }





            } catch (Exception)
            {

                MessageBox.Show("Неверный логин или пароль!");
            }

        }
    }
}
