﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Models
{
    public class Task
    {
        public string DateOfCompletion { get; set; }

        public string description { get; set; }

        public string status { get; set; }

        public string title { get; set; }

        public string DateOfFinish { get; set; }

        public string idTask { get; set; }

        [JsonIgnore]
        public User user { get; set; }

        [JsonIgnore]
        public string taskId { get; set; }

        [JsonIgnore]
        public string UID { get; set; }

    }
}
